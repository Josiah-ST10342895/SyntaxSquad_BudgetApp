package com.example.poe_part2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class dashboard : AppCompatActivity() {
    private lateinit var ideabtn: Button
//    private lateinit var homebtn: Button
    private lateinit var btnhistory: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_dashboard)

        ideabtn = findViewById(R.id.Tips)
//        homebtn = findViewById(R.id.home)
        btnhistory = findViewById(R.id.payment_history)


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

//        homebtn.setOnClickListener {
//            // Redirect to dashboardActivity
//            startActivity(Intent(this, dashboard::class.java))
//            // Optional: Add transition animation
//            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//        }
        ideabtn.setOnClickListener {
            // Redirect to TipsActivity
            startActivity(Intent(this, tips::class.java))
            // Optional: Add transition animation
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
        btnhistory.setOnClickListener {
            // Redirect to HistoryActivity
            startActivity(Intent(this, history::class.java))
            // Optional: Add transition animation
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }
}