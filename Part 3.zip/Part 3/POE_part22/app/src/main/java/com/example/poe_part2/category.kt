package com.example.poe_part2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.firestore.FirebaseFirestore

class category : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()

    private lateinit var createcat: TextInputEditText
    private lateinit var savebtn: Button
    private lateinit var ideabtn: Button
    private lateinit var homebtn: Button
    private lateinit var btnhistory: Button
    private lateinit var btncancel: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_category)

        createcat = findViewById(R.id.catid)
        savebtn = findViewById(R.id.nextButton)
        ideabtn = findViewById(R.id.btnIdea)
        homebtn = findViewById(R.id.btnHome)
        btnhistory = findViewById(R.id.btnhis)
        btncancel = findViewById(R.id.btncan)



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        savebtn.setOnClickListener {
            val categoryName = createcat.text.toString().trim()
            createCategory(categoryName)
        }
        ideabtn.setOnClickListener {
            // Redirect to TipsActivity
            startActivity(Intent(this, tips::class.java))
            // Optional: Add transition animation
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
        homebtn.setOnClickListener {
        // Redirect to dashboardActivity
        startActivity(Intent(this, dashboard::class.java))
        // Optional: Add transition animation
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
        btnhistory.setOnClickListener {
            // Redirect to HistoryActivity
            startActivity(Intent(this, history::class.java))
            // Optional: Add transition animation
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
        btncancel.setOnClickListener {
            // Redirect to DashboardActivity
            startActivity(Intent(this, dashboard::class.java))
            // Optional: Add transition animation
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }

    private fun createCategory(categoryName: String) {
        if (categoryName.isEmpty()) {
            createcat.error = "Category name is required"
            return
        }

        val category = hashMapOf(
            "name" to categoryName,
            "createdAt" to System.currentTimeMillis()
        )

        db.collection("categories")
            .add(category)
            .addOnSuccessListener { documentReference ->
                Toast.makeText(
                    this,
                    "Category created with ID: ${documentReference.id}",
                    Toast.LENGTH_SHORT
                ).show()
                createcat.text?.clear()
            }
            .addOnFailureListener { e ->
                Toast.makeText(
                    this,
                    "Error creating category: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
    }
}