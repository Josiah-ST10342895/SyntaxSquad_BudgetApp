package com.example.budgetapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.budgetapp.Database.AppDatabase
import com.example.budgetapp.Database.category
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.launch

class ViewCategoriesActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private lateinit var adapter: CategoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_cat)

        // Initialize database
        db = AppDatabase.getDatabase(this)

        // Setup RecyclerView
        val recyclerView = findViewById<RecyclerView>(R.id.categoriesRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = CategoryAdapter(emptyList()) { selectedCategory ->
            navigateToExpenseEntry(selectedCategory)
        }
        recyclerView.adapter = adapter

        // Load categories
        loadCategories()

        // Setup FAB
        findViewById<FloatingActionButton>(R.id.fabAddCategory).setOnClickListener {
            navigateToCreateCategory()
        }
    }

    private fun loadCategories() {
        lifecycleScope.launch {
            val categories = db.categoryDao().getAllCategories()
            adapter.updateList(categories)
        }
    }

    private fun navigateToExpenseEntry(category: category) {
        startActivity(Intent(this, ExpenseEntryActivity::class.java).apply {
            putExtra("category_id", category.cat_id)
            putExtra("category_name", category.catname)
        }

    }

    private fun navigateToCreateCategory() {
        startActivity(Intent(this, CreateCategoryActivity::class.java))
    }
}
