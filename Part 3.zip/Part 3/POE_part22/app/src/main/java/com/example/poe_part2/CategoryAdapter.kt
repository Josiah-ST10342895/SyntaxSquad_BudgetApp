package com.example.budgetapp

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.budgetapp.Database.category

class CategoryAdapter(
    private var categories: List<category>,
    private val onItemClick: (category) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.ViewHolder>() {

    inner class ViewHolder(parent: ViewGroup) : RecyclerView.ViewHolder(
        LayoutInflater.from(parent.context)
            .inflate(R.layout.item_category, parent, false)
    ) {
        val name = itemView.findViewById<TextView>(R.id.categoryName)
        val selectButton = itemView.findViewById<Button>(R.id.selectButton)
    }

    fun updateList(newList: List<category>) {
        categories = newList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(parent)

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val category = categories[position]
        holder.name.text = category.catname
        holder.selectButton.setOnClickListener { onItemClick(category) }
    }

    override fun getItemCount() = categories.size
}