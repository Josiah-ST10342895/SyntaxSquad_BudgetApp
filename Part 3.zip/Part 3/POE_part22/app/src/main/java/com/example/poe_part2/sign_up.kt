package com.example.poe_part2

    import android.os.Bundle
    import android.widget.Button
    import android.widget.Toast
    import androidx.activity.enableEdgeToEdge
    import androidx.appcompat.app.AppCompatActivity
    import androidx.core.view.ViewCompat
    import androidx.core.view.WindowInsetsCompat
    import com.google.android.material.textfield.TextInputEditText
    import com.google.firebase.firestore.FirebaseFirestore

    class sign_up : AppCompatActivity() {

        private val db = FirebaseFirestore.getInstance()

        private lateinit var usernameInput: TextInputEditText
        private lateinit var passwordInput: TextInputEditText
        private lateinit var conpass: TextInputEditText
        private lateinit var Sign_upBtn: Button

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            enableEdgeToEdge()
            setContentView(R.layout.activity_sign_up)

            // Initialize views
            usernameInput = findViewById(R.id.username)
            passwordInput = findViewById(R.id.password)
            conpass = findViewById(R.id.con_password)
            Sign_upBtn = findViewById(R.id.sign_up)

            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
                insets
            }

            Sign_upBtn.setOnClickListener {
                saveUserToFirestore()
            }
        }

        private fun saveUserToFirestore() {
            val username = usernameInput.text.toString().trim()
            val password = passwordInput.text.toString().trim()

            if (username.isEmpty()) {
                usernameInput.error = "Username is required"
                return
            }

            if (password.isEmpty()) {
                passwordInput.error = "Password is required"
                return
            }

            // Create a user data map
            val user = hashMapOf(
                "username" to username,
                "password" to password
            )

            db.collection("users")
                .add(user)
                .addOnSuccessListener { documentReference ->
                    Toast.makeText(
                        this,
                        "User registered with ID: ${documentReference.id}",
                        Toast.LENGTH_SHORT
                    ).show()

                    usernameInput.text?.clear()
                    passwordInput.text?.clear()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(
                        this,
                        "Error registering user: ${e.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
        }
    }