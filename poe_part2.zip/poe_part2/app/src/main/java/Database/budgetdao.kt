package Database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

interface budgetdao {
    @Dao
    interface UserDao {
        @Insert
        suspend fun insert(user_insert: users)
    }

    @Dao
    interface  expenseDao {
        @Insert
        suspend fun insert(expinsert: expenses)

        @Update
        suspend fun update(expupdate: expenses)

        @Delete
        suspend fun delete(expdelete: expenses)

        @Query("SELECT * FROM users WHERE user_id = :userId")
        fun getUserById(userId: Int): LiveData<expenses>

        @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
        suspend fun getUserByUsername(username: String): expenses?
    }
    @Dao
    interface budgetDao{
        @Insert
        suspend fun insert(budinsert: Budget)
    }
    @Dao
    interface categoryDao{
        @Insert
        suspend fun insert(catinsert: category)
    }

}