package Database

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import android.content.Context

@Database(entities = [Budget::class], version = 1)
abstract class budgetdatabase: RoomDatabase() {
    abstract fun getbudgetdao(): budgetdao
    companion object{
        @Volatile
        private var instance: budgetdatabase? = null
        private val LOCK = Any()

        operator fun invoke(context: Context) = instance ?:
        synchronized(LOCK){
            instance ?:
            createDatabase(context).also{ instance = it
            }
        }
        private fun createDatabase(context: Context) =
            Room.databaseBuilder(
                context.applicationContext,budgetdatabase::class.java,
                name = "budget_db").build()

    }
}