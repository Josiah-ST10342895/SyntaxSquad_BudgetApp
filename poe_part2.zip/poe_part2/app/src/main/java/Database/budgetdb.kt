package Database

import androidx.room.Entity
import java.util.Date
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class users(
    @PrimaryKey (autoGenerate = true)
    val user_id: Int = 0,
    val username: String,
    val password: String,
    val email: String,

    )
@Entity(tableName = "Expense")
data class expenses(
    @PrimaryKey (autoGenerate = true)
    val expense_id: Int = 0,
    val expense_title: String,
    val expense_amount: Int,
    val expense_date: Date,
    val expense_photo: String,
    val expense_filepath: String,

    )
@Entity(tableName = "Budget")
data class Budget(
    @PrimaryKey (autoGenerate = true)
    val budget_id: Int = 0,
    val mingoal: Int,
    val maxgoal: Int,
)
@Entity(tableName = "Category")
data class category(
    @PrimaryKey (autoGenerate = true)
    val cat_id: Int = 0,
    val catname: String,
)



