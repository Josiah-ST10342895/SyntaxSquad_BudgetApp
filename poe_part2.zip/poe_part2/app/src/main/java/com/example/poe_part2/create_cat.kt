package com.example.poe_part2


import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

import com.example.trial_app.R
import com.google.android.material.textfield.TextInputEditText

class CreateCategoryActivity : AppCompatActivity() {

    private lateinit var titleInput: TextInputEditText
    private lateinit var nextButton: Button
    private lateinit var cancelButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_cat)

        titleInput = findViewById(R.id.CAT_Name_Input)
        nextButton = findViewById(R.id.nextButton)
        cancelButton = findViewById(R.id.btnCancel)

        nextButton.setOnClickListener {
            val title = titleInput.text?.toString()?.trim()

            if (title.isNullOrEmpty()) {
                Toast.makeText(this, "Please enter a category name", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(this, ExpenseEntryActivity::class.java)
                intent.putExtra("category_title", title)
                startActivity(intent)
            }
        }

        cancelButton.setOnClickListener {
            finish() // Close the activity
        }
    }
}
