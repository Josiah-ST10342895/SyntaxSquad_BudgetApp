package com.example.poe_part2

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.trial_app.R

class ExpenseEntryActivity : AppCompatActivity() {

    private lateinit var attachPhotoButton: Button
    private lateinit var imagePreview: ImageView

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            imagePreview.setImageURI(it)
            imagePreview.visibility = View.VISIBLE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_expense_entry)

        val title = intent.getStringExtra("category_title")

        attachPhotoButton = findViewById(R.id.btnAttachPhoto)
        imagePreview = findViewById(R.id.imgReceiptPreview)

        attachPhotoButton.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        Toast.makeText(this, "Category: $title", Toast.LENGTH_SHORT).show()
    }
}
